${packageName ? 'package ' + packageName + ';' : '' }

import javax.inject.Singleton;

@Singleton
public class ${className} {

}