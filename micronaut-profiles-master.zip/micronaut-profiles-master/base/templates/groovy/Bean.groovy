${packageName ? 'package ' + packageName : '' }

import javax.inject.Singleton

@Singleton
class ${className} {

}