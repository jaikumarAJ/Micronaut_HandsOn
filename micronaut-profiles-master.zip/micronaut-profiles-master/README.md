Micronaut Profiles
=========================

This repository contains the profiles able to be used when creating Micronaut applications

A profile is a set of application templates and commands that enable distinct development environments for the Micronaut framework.
