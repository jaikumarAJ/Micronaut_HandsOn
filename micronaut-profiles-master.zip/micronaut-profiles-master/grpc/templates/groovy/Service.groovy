${packageName ? 'package ' + packageName : '' }

import javax.inject.Singleton

@Singleton
public class ${className} extends ${className}Grpc.${className}ImplBase { 

}