package @defaultPackage@

String @project.propertyName@() {
    "@project.name@"
}