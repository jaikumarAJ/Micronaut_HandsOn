Execute UI tests:

`./gradlew connectedAndroidTest`