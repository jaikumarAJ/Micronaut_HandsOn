package demo.micronautdiandroid;

interface BooksFetcher {
    void fetchBooks(OnBooksFetched onBooksFetched);
}
