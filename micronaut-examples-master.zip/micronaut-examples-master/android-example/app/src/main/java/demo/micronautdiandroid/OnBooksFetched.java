package demo.micronautdiandroid;

import java.util.List;

interface OnBooksFetched {
    void booksFetched(List<Book> books);
}
