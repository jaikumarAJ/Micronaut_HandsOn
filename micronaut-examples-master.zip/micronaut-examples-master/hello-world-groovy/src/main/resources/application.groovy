micronaut {
    executors {
        io {
            type = "fixed"
            nThreads = 75
        }
    }
}
