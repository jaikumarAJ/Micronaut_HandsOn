package example.storefront

import groovy.transform.CompileStatic

@CompileStatic
class MailFormSubmission {
    String email
    String slug
}
