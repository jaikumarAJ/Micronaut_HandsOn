To use [Amazon AWS SES](https://aws.amazon.com/ses/) configure in `src/main/resources/application.properties`.

aws.ses.region=eu-west-1
aws.sourceEmail=verifiedemail@email.com
aws.accessKeyId=XXXXAAAXXXX
aws.secretKey=YYYYYZZZZXXXX

To use SendGrid configure in `src/main/resources/application.properties`.

sendgrid.apiKey=XXXXX
sendgrid.fromEmail=sergio.delamo@softamo.com