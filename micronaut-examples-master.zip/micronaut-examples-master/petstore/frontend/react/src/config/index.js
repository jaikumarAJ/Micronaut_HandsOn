const config = {
    'SERVER_URL': 'http://localhost:8080'
}

export default config;