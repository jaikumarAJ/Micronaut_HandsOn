package app

import io.micronaut.ktor.*

fun main(args: Array<String>) {
    runApplication(args)
}